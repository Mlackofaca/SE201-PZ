/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Koncert {

    private int koncertId;
    private Date datum;
    private String lokacija;
    private double zarada;
    private List<Izvodjac> izvodjaci;
    private List<Pesma> pesme;
    private List<NovcaniPrihod> novcaniPrihodi;
    private List<String> trendovi;
    private List<Ugovor> ugovori;

    public Koncert(Date datum, String lokacija, double zarada) {
        this.datum = datum;
        this.lokacija = lokacija;
        this.zarada = zarada;
        this.izvodjaci = new ArrayList<>();
        this.pesme = new ArrayList<>();
        this.novcaniPrihodi = new ArrayList<>();
        this.ugovori = new ArrayList<>();
        this.trendovi = new ArrayList<>();
    }

    public int getKoncertId() {
        return koncertId;
    }

    public List<Ugovor> getUgovori() {
        return ugovori;
    }

    public void setUgovori(List<Ugovor> ugovori) {
        this.ugovori = ugovori;
    }

    public void setKoncertId(int koncertId) {
        this.koncertId = koncertId;
    }

    public List<Izvodjac> getIzvodjaci() {
        return izvodjaci;
    }

    public void setIzvodjaci(List<Izvodjac> izvodjaci) {
        this.izvodjaci = izvodjaci;
    }

    public List<String> getTrendovi() {
        return trendovi;
    }

    public void dodajTrend(String trend) {
        this.trendovi.add(trend);
    }

    public List<Pesma> getPesme() {
        return pesme;
    }

    public void setPesme(List<Pesma> pesme) {
        this.pesme = pesme;
    }

    public List<NovcaniPrihod> getNovcaniPrihodi() {
        return novcaniPrihodi;
    }

    public void setNovcaniPrihodi(List<NovcaniPrihod> novcaniPrihodi) {
        this.novcaniPrihodi = novcaniPrihodi;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public double getZarada() {
        return zarada;
    }

    public void setZarada(double zarada) {
        this.zarada = zarada;
    }

    @Override
    public String toString() {
        return "Koncert{" + "koncertId=" + koncertId + ", datum=" + datum + ", lokacija=" + lokacija + ", zarada=" + zarada + ", izvodjaci=" + izvodjaci + ", pesme=" + pesme + ", novcaniPrihodi=" + novcaniPrihodi + ", trendovi=" + trendovi + ", ugovori=" + ugovori + '}';
    }

    // Dodavanje ugovora
    public void dodajNovcaniPrihod(NovcaniPrihod novcaniPrihod, List<Ugovor> ugovori) {
        if (novcaniPrihodi == null) {
            novcaniPrihodi = new ArrayList<>();
        }
        novcaniPrihodi.add(novcaniPrihod);
        this.zarada += novcaniPrihod.getIznos();
        // Dodavanje ugovora
        if (ugovori != null) {
            this.ugovori.addAll(ugovori);
        }
    }

    public void dodajUgovor(Ugovor ugovor) {
        if (ugovori == null) {
            ugovori = new ArrayList<>();
        }
        ugovori.add(ugovor);
    }

    public void dodajNovcaniPrihod(NovcaniPrihod novcaniPrihod) {
        if (novcaniPrihodi == null) {
            novcaniPrihodi = new ArrayList<>();
        }
        novcaniPrihodi.add(novcaniPrihod);
        this.zarada += novcaniPrihod.getIznos();
    }

    // Metoda za prikaz finansijskih transakcija koncerata
    public void prikaziFinansijskeTransakcije() {
        System.out.println("Finansijske transakcije za koncert (ID: " + this.koncertId + "):");
        if (novcaniPrihodi != null && !novcaniPrihodi.isEmpty()) {
            for (NovcaniPrihod np : novcaniPrihodi) {
                System.out.println("Datum: " + np.getDatum() + ", Iznos: " + np.getIznos());
            }
            System.out.println("Ukupna zarada: " + this.zarada);
        } else {
            System.out.println("Nema finansijskih transakcija za ovaj koncert.");
        }
        System.out.println();
    }
}

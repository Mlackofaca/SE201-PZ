/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Obavestenje {

    private String naslov;
    private String sadrzaj;
    private Date datumObjave;
    private String izvor;
    private List<String> komentari;
    private String posiljalac;

    public Obavestenje(String naslov, String sadrzaj, Date datumObjave, String izvor) {
        this.naslov = naslov;
        this.sadrzaj = sadrzaj;
        this.datumObjave = datumObjave;
        this.izvor = izvor;
        this.komentari = new ArrayList<>();
    }

    public String getIzvor() {
        return izvor;
    }

    public void setIzvor(String izvor) {
        this.izvor = izvor;
    }

    public List<String> getKomentari() {
        return komentari;
    }

    public void dodajKomentar(String komentar) {
        komentari.add(komentar);
    }

    // Metoda za prikaz informacija o obavestenju
    public void prikaziInformacije() {
        System.out.println("Naslov: " + naslov);
        System.out.println("Sadrzaj: " + sadrzaj);
        System.out.println("Datum objave: " + datumObjave);
        System.out.println("Izvor: " + izvor);

        if (!komentari.isEmpty()) {
            System.out.println("Komentari:");
            for (String komentar : komentari) {
                System.out.println("- " + komentar);
            }
        }
    }

    public String getNaslov() {
        return naslov;
    }

    public String getPosiljalac() {
        return posiljalac;
    }

    @Override
    public String toString() {
        return "Obavestenje{" + "naslov=" + naslov + ", sadrzaj=" + sadrzaj + ", datumObjave=" + datumObjave + ", izvor=" + izvor + ", komentari=" + komentari + ", posiljalac=" + posiljalac + '}';
    }

    public Date getDatumObjave() {
        return datumObjave;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.Date;

public class NovcaniPrihod {

    private Date datum;
    private double iznos;

    public NovcaniPrihod(Date datum, double iznos) {
        this.datum = datum;
        this.iznos = iznos;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public double getIznos() {
        return iznos;
    }

    public void setIznos(double iznos) {
        this.iznos = iznos;
    }

    @Override
    public String toString() {
        return "NovcaniPrihod{" + "datum=" + datum + ", iznos=" + iznos + '}';
    }

}

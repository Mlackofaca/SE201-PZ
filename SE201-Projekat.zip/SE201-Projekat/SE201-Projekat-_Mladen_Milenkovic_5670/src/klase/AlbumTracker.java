/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.ArrayList;
import java.util.List;

public class AlbumTracker {

    private List<Album> albumi;

    public AlbumTracker(List<Album> albumi) {
        this.albumi = albumi;
    }

    public AlbumTracker() {
        this.albumi = new ArrayList<>();
    }

    public void dodajAlbum(Album album) {
        albumi.add(album);
    }

    public List<Album> getAlbumi() {
        return albumi;
    }

    @Override
    public String toString() {
        return "AlbumTracker{" + "albumi=" + albumi + '}';
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.Date;

public class Kampanja {

    private String naziv;
    private Date datumPocetka;
    private Date datumZavrsetka;
    private double ciljnaSuma;
    private double prikupljenaSuma;
    private String letnja_turneja;
    private String popust_na_ulaznice;

    public Kampanja(String naziv, Date datumPocetka, Date datumZavrsetka, double ciljnaSuma) {
        this.naziv = naziv;
        this.datumPocetka = datumPocetka;
        this.datumZavrsetka = datumZavrsetka;
        this.ciljnaSuma = ciljnaSuma;
        this.prikupljenaSuma = 0.0;
        this.letnja_turneja = letnja_turneja;
        this.popust_na_ulaznice = popust_na_ulaznice;
    }

    public String getLetnja_turneja() {
        return letnja_turneja;
    }

    public void setLetnja_turneja(String letnja_turneja) {
        this.letnja_turneja = letnja_turneja;
    }

    public String getPopust_na_ulaznice() {
        return popust_na_ulaznice;
    }

    public void setPopust_na_ulaznice(String popust_na_ulaznice) {
        this.popust_na_ulaznice = popust_na_ulaznice;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Date getDatumPocetka() {
        return datumPocetka;
    }

    public void setDatumPocetka(Date datumPocetka) {
        this.datumPocetka = datumPocetka;
    }

    public Date getDatumZavrsetka() {
        return datumZavrsetka;
    }

    public void setDatumZavrsetka(Date datumZavrsetka) {
        this.datumZavrsetka = datumZavrsetka;
    }

    public double getCiljnaSuma() {
        return ciljnaSuma;
    }

    public void setCiljnaSuma(double ciljnaSuma) {
        this.ciljnaSuma = ciljnaSuma;
    }

    public double getPrikupljenaSuma() {
        return prikupljenaSuma;
    }

    public void setPrikupljenaSuma(double prikupljenaSuma) {
        this.prikupljenaSuma = prikupljenaSuma;
    }

    // Metoda za dodavanje prikupljene sume
    public void dodajPrikupljenuSumu(double iznos) {
        this.prikupljenaSuma += iznos;
    }

    @Override
    public String toString() {
        return "Kampanja{" + "naziv=" + naziv + ", datumPocetka=" + datumPocetka + ", datumZavrsetka=" + datumZavrsetka + ", ciljnaSuma=" + ciljnaSuma + ", prikupljenaSuma=" + prikupljenaSuma + ", letnja_turneja=" + letnja_turneja + ", popust_na_ulaznice=" + popust_na_ulaznice + '}';
    }

}

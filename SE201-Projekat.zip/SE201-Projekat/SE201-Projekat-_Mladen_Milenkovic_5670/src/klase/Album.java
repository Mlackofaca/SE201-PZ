/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Album {

    private String naziv;
    private List<Pesma> pesme;
    private int izvodjacId;
    private Izvodjac izvodjac;
    private int godinaIzdanja;
    private String zanr;
    private double ocenaKorisnika;

    private static final String VALID_GENRE_PATTERN = "^[a-zA-Z]+$";

    public Album(String naziv, List<Pesma> pesme, int izvodjacId, Izvodjac izvodjac, int godinaIzdanja, String zanr, double ocenaKorisnika) {
        this.naziv = naziv;
        this.pesme = pesme;
        this.izvodjacId = izvodjacId;
        this.izvodjac = izvodjac;
        this.godinaIzdanja = godinaIzdanja;
        setZanr(zanr); // Validacija i postavljanje žanra
        this.ocenaKorisnika = ocenaKorisnika;
    }

    public void setZanr(String zanr) {
        if (isValidGenre(zanr)) {
            this.zanr = zanr;
        } else {
            throw new IllegalArgumentException("Nevalidan žanr.");
        }
    }

    private boolean isValidGenre(String zanr) {
        Pattern pattern = Pattern.compile(VALID_GENRE_PATTERN);
        Matcher matcher = pattern.matcher(zanr);
        return matcher.matches();
    }

    public int getGodinaIzdanja() {
        return godinaIzdanja;
    }

    public void setGodinaIzdanja(int godinaIzdanja) {
        this.godinaIzdanja = godinaIzdanja;
    }

    public String getZanr() {
        return zanr;
    }

    public double getOcenaKorisnika() {
        return ocenaKorisnika;
    }

    public void setOcenaKorisnika(double ocenaKorisnika) {
        this.ocenaKorisnika = ocenaKorisnika;
    }

    public Album(String naziv) {
        this.naziv = naziv;
        this.pesme = new ArrayList<>();
    }

    public int getIzvodjacId() {
        return izvodjacId;
    }

    public void setIzvodjacId(int izvodjacId) {
        this.izvodjacId = izvodjacId;
    }

    public void dodajPesmu(Pesma pesma) {
        pesme.add(pesma);
    }

    public List<Pesma> getPesme() {
        return pesme;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "Album{" + "naziv=" + naziv + ", pesme=" + pesme + ", izvodjacId=" + izvodjacId + ", izvodjac=" + izvodjac + ", godinaIzdanja=" + godinaIzdanja + ", zanr=" + zanr + ", ocenaKorisnika=" + ocenaKorisnika + '}';
    }

    public void addPesma(Connection connection, Pesma pesma) throws SQLException {
        String query = "INSERT INTO pesme (naziv, trajanje, izvodjac_id, album_naziv) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, pesma.getNaziv());

            // Postavljanje trajanja kao objekta
            preparedStatement.setObject(2, pesma.getTrajanje());

            preparedStatement.setInt(3, pesma.getIzvodjacId());
            preparedStatement.setString(4, this.naziv);

            preparedStatement.executeUpdate();
        }
    }

    public void dodajUBazu(Connection connection) throws SQLException {
        String query = "INSERT INTO albumi (naziv) VALUES (?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, this.getNaziv());
            preparedStatement.executeUpdate();
        }

        for (Pesma pesma : this.getPesme()) {
            pesma.dodajUBazu(connection);
        }

    }
    // Metoda za ažuriranje naziva albuma u bazi

    public void azurirajAlbumNaziv(Connection connection, String noviNaziv) throws SQLException {
        String query = "UPDATE albumi SET naziv = ? WHERE izvodjac_id = ? AND naziv = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, noviNaziv);
            preparedStatement.setInt(2, this.izvodjacId);
            preparedStatement.setString(3, this.naziv);

            preparedStatement.executeUpdate();
        }
    }

    // Metoda za brisanje albuma iz baze
    public void obrisiAlbum(Connection connection) throws SQLException {
        String query = "DELETE FROM albumi WHERE izvodjac_id = ? AND naziv = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.izvodjacId);
            preparedStatement.setString(2, this.naziv);

            preparedStatement.executeUpdate();
        }

    }

    public Izvodjac getIzvodjac() {
        return izvodjac;
    }

}

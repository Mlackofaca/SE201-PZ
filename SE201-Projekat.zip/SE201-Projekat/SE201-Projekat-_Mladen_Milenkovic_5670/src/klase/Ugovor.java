/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

public class Ugovor {

    private String tip;
    private double cena;
    private Izvodjac izvodjac;
    private Koncert koncert;

    public Ugovor(String tip, double cena) {
        this.tip = tip;
        this.cena = cena;
    }

    public Izvodjac getIzvodjac() {
        return izvodjac;
    }

    public void setIzvodjac(Izvodjac izvodjac) {
        this.izvodjac = izvodjac;
    }

    public Koncert getKoncert() {
        return koncert;
    }

    public void setKoncert(Koncert koncert) {
        this.koncert = koncert;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    @Override
    public String toString() {
        return "Ugovor{" + "tip=" + tip + ", cena=" + cena + ", izvodjac=" + izvodjac + ", koncert=" + koncert + '}';
    }
}

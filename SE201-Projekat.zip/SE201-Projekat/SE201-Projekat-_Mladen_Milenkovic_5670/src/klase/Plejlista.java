/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.ArrayList;
import java.util.List;

public class Plejlista {

    private String naziv;
    private List<Pesma> pesme;
    private List<Izvodjac> izvodjaci;
    private List<Koncert> koncerti;

    public Plejlista(String naziv) {
        this.naziv = naziv;
        this.pesme = new ArrayList<>();
        this.izvodjaci = new ArrayList<>();
        this.koncerti = new ArrayList<>();
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public void setPesme(List<Pesma> pesme) {
        this.pesme = pesme;
    }

    public void setIzvodjaci(List<Izvodjac> izvodjaci) {
        this.izvodjaci = izvodjaci;
    }

    public void setKoncerti(List<Koncert> koncerti) {
        this.koncerti = koncerti;
    }

    public void dodajPesmu(Pesma pesma) {
        pesme.add(pesma);
    }

    public void dodajIzvodjaca(Izvodjac izvodjac) {
        izvodjaci.add(izvodjac);
    }

    public void dodajKoncert(Koncert koncert) {
        koncerti.add(koncert);
    }

    public List<Pesma> getPesme() {
        return pesme;
    }

    public List<Izvodjac> getIzvodjaci() {
        return izvodjaci;
    }

    public List<Koncert> getKoncerti() {
        return koncerti;
    }

    public String getNaziv() {
        return naziv;
    }

    @Override
    public String toString() {
        return "Plejlista{" + "naziv=" + naziv + ", pesme=" + pesme + ", izvodjaci=" + izvodjaci + ", koncerti=" + koncerti + '}';
    }

}

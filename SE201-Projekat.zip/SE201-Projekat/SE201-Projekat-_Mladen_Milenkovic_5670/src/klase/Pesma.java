/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Pesma {

    private String naziv;
    private LocalTime trajanje;
    private int izvodjacId;
    private String pesmaId;
    private Album album;
    private List<String> trendovi;
    private String ugovor;

    public Pesma(String naziv, LocalTime trajanje, int izvodjacId, Album album) {
        this.naziv = naziv;
        this.trajanje = trajanje;
        this.izvodjacId = izvodjacId;
        this.album = album;
        this.trendovi = new ArrayList<>();
        this.ugovor = "";

    }

    public Pesma(String naziv, String trajanje, int izvodjacId, Album album) {
        this.naziv = naziv;
        this.trajanje = convertStringToTime(trajanje);
        this.izvodjacId = izvodjacId;
        this.album = album;
    }

    public Pesma(String naziv, String trajanje) {
        this.naziv = naziv;
        this.trajanje = convertStringToTime(trajanje);
        this.izvodjacId = 0;
    }

    private static LocalTime convertStringToTime(String trajanje) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        return LocalTime.parse(trajanje, formatter);
    }

    public List<String> getTrendovi() {
        return trendovi;
    }

    public void setTrendovi(List<String> trendovi) {
        this.trendovi = trendovi;
    }

    public void dodajTrend(String trend) {
        this.trendovi.add(trend);
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public LocalTime getTrajanje() {
        return trajanje;
    }

    public void setTrajanje(LocalTime trajanje) {
        this.trajanje = trajanje;
    }

    public int getIzvodjacId() {
        return izvodjacId;
    }

    public void setIzvodjacId(int izvodjacId) {
        this.izvodjacId = izvodjacId;
    }

    public String getPesmaId() {
        return pesmaId;
    }

    public void setPesmaId(String pesmaId) {
        this.pesmaId = pesmaId;
    }

    public String getUgovor() {
        return ugovor;
    }

    public void setUgovor(String ugovor) {
        this.ugovor = ugovor;
    }

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

    @Override
    public String toString() {
        return "Pesma{" + "naziv=" + naziv + ", trajanje=" + trajanje + ", izvodjacId=" + izvodjacId + ", pesmaId=" + pesmaId + ", album=" + album + ", trendovi=" + trendovi + ", ugovor=" + ugovor + '}';
    }

    public void dodajUBazu(Connection connection) throws SQLException {
        String query = "INSERT INTO pesme (naziv, trajanje, izvodjac_id, album_naziv) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(query)) {
            preparedStatement.setString(1, this.getNaziv());
            preparedStatement.setObject(2, this.getTrajanje());
            preparedStatement.setInt(3, this.getIzvodjacId());

            if (this.getAlbum() != null) {
                preparedStatement.setString(4, this.getAlbum().getNaziv());
            } else {
                preparedStatement.setNull(4, java.sql.Types.VARCHAR);
            }

            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLException("Greška prilikom dodavanja pesme u bazu: " + ex.getMessage());
        }
    }

}

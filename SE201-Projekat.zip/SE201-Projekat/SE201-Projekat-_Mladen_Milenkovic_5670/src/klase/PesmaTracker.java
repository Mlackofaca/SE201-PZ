/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.ArrayList;
import java.util.List;

public class PesmaTracker {
    private List<Pesma> pesme;

    public PesmaTracker() {
        this.pesme = new ArrayList<>();
    }

    public void dodajPesmu(Pesma pesma) {
        pesme.add(pesma);
    }

    public List<Pesma> getPesme() {
        return pesme;
    }

    @Override
    public String toString() {
        return "PesmaTracker{" + "pesme=" + pesme + '}';
    }
}
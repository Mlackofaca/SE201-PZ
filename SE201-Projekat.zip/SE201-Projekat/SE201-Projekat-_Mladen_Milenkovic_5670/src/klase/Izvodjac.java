/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Izvodjac {

    private String ime;
    private List<Album> albumi;
    private List<Pesma> pesme;
    private int izvodjacId;
    private int popularnost;
    private List<String> trendovi;
    private String ugovor;
    private List<NovcaniPrihod> novcaniPrihodi;
    private List<Ugovor> ugovori;

    public Izvodjac(String ime, List<Album> albumi, List<Pesma> pesme, int izvodjacId, int popularnost) {
        this.ime = ime;
        this.albumi = albumi;
        this.pesme = pesme;
        this.izvodjacId = izvodjacId;
        this.popularnost = popularnost;
        this.trendovi = new ArrayList<>();
        this.ugovor = "";
        this.novcaniPrihodi = novcaniPrihodi;
    }

    public Izvodjac(String izvodjacIme) {
        this.ime = izvodjacIme;
        this.albumi = new ArrayList<>();
        this.pesme = new ArrayList<>();
        this.izvodjacId = 0;
        this.popularnost = 0;
        this.trendovi = new ArrayList<>();
        this.ugovor = "";
    }

    public void dodajUgovor(Ugovor ugovor) {
        if (ugovori == null) {
            ugovori = new ArrayList<>();
        }
        ugovori.add(ugovor);
    }

    public int getPopularnost() {
        return popularnost;
    }

    public void setPopularnost(int popularnost) {
        this.popularnost = popularnost;
    }

    public List<Ugovor> getUgovori() {
        return ugovori;
    }

    public void setUgovori(List<Ugovor> ugovori) {
        this.ugovori = ugovori;
    }

    @Override
    public String toString() {
        return "Izvodjac{" + "ime=" + ime + ", albumi=" + albumi + ", pesme=" + pesme + ", izvodjacId=" + izvodjacId + ", popularnost=" + popularnost + ", trendovi=" + trendovi + ", ugovor=" + ugovor + ", novcaniPrihodi=" + novcaniPrihodi + ", ugovori=" + ugovori + '}';
    }

    public int getIzvodjacId() {
        return izvodjacId;
    }

    public void setIzvodjacId(int izvodjacId) {
        this.izvodjacId = izvodjacId;
    }

    public void dodajAlbum(Album album) {
        albumi.add(album);
    }

    public List<Album> getAlbumi() {
        return albumi;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public void addAlbum(Connection connection, Album album) throws SQLException {
        String query = "INSERT INTO albumi (izvodjac_id, naziv) VALUES (?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.izvodjacId);
            preparedStatement.setString(2, album.getNaziv());

            preparedStatement.executeUpdate();
        }
    }

    public void ucitajPesme(Connection connection) {
        List<Pesma> pesme = new ArrayList<>();
        String query = "SELECT naziv, trajanje FROM pesme WHERE izvodjac_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.izvodjacId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    String naziv = resultSet.getString("naziv");
                    String trajanje = resultSet.getString("trajanje");

                    Pesma pesma = new Pesma(naziv, trajanje);
                    pesme.add(pesma);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        this.pesme = pesme;
    }

    public List<Pesma> getPesme() {
        return pesme;
    }

    public void povecajPopularnost() {
        this.popularnost++;
    }

    public List<String> getTrendovi() {
        return trendovi;
    }

    public void setTrendovi(List<String> trendovi) {
        this.trendovi = trendovi;
    }

    public void dodajTrend(String trend) {
        this.trendovi.add(trend);
    }

    public String getUgovor() {
        return ugovor;
    }

    public void setUgovor(String ugovor) {
        this.ugovor = ugovor;
    }

    public void dodajNovcaniPrihod(NovcaniPrihod novcaniPrihod) {
        if (novcaniPrihodi == null) {
            novcaniPrihodi = new ArrayList<>();
        }
        novcaniPrihodi.add(novcaniPrihod);
    }

    public void setNovcaniPrihodi(List<NovcaniPrihod> novcaniPrihodi) {
        this.novcaniPrihodi = novcaniPrihodi;
    }

    // Metoda za ažuriranje izvođača u bazi
    public void azurirajIzvodjaca(Connection connection) throws SQLException {
        String query = "UPDATE izvodjaci SET popularnost = ? WHERE izvodjac_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.popularnost);
            preparedStatement.setInt(2, this.izvodjacId);

            preparedStatement.executeUpdate();
        }
    }

    // Metoda za brisanje izvođača iz baze
    public void obrisiIzvodjaca(Connection connection) throws SQLException {
        String query = "DELETE FROM izvodjaci WHERE izvodjac_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.izvodjacId);

            preparedStatement.executeUpdate();
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.util.ArrayList;
import java.util.List;

public class Fan {

    private int fanId;
    private String ime;
    private AlbumTracker albumTracker;
    private PesmaTracker pesmaTracker;
    private List<Plejlista> plejliste;
    private List<Izvodjac> omiljeniIzvodjaci;
    private List<Obavestenje> obavestenja;
    private List<Izvodjac> praceniIzvodjaci;
    private String prezime;
    private String email;

    public Fan() {
        this.albumTracker = new AlbumTracker();
        this.pesmaTracker = new PesmaTracker();
        this.plejliste = new ArrayList<>();
        this.omiljeniIzvodjaci = new ArrayList<>();
        this.obavestenja = new ArrayList<>();
        this.praceniIzvodjaci = new ArrayList<>();

    }
    private static final String VALID_EMAIL_PATTERN = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

    public Fan(String ime, String prezime, String email) {
        this(); 

        // Validacija i postavljanje imena
        if (!isValidString(ime)) {
            // Ako ime nije validno, bacamo izuzetak
            throw new IllegalArgumentException("Nevalidno ime.");
        }

        // Validacija i postavljanje prezimena
        if (!isValidString(prezime) || !isValidLastName(prezime)) {
            // Ako prezime nije validno, bacamo izuzetak
            throw new IllegalArgumentException("Nevalidno prezime.");
        }

        // Postavljanje email-a
        if (!isValidEmail(email)) {
            // Ako email nije validan, bacamo izuzetak
            throw new IllegalArgumentException("Nevalidna email adresa.");
        }

        this.ime = ime;
        this.prezime = prezime;
        this.email = email;
    }

    public static boolean isValidEmail(String email) {
        return email != null && email.matches(VALID_EMAIL_PATTERN);
    }

    public static boolean isValidLastName(String prezime) {
        return isValidString(prezime) && prezime.length() <= 50;
    }

    public static boolean isValidString(String str) {
        return str != null && !str.isEmpty();
    }

    @Override
    public String toString() {
        return "Fan{" + "fanId=" + fanId + ", ime=" + ime + ", albumTracker=" + albumTracker + ", pesmaTracker=" + pesmaTracker + ", plejliste=" + plejliste + ", omiljeniIzvodjaci=" + omiljeniIzvodjaci + ", obavestenja=" + obavestenja + ", praceniIzvodjaci=" + praceniIzvodjaci + ", prezime=" + prezime + ", email=" + email + '}';
    }

    public int getFanId() {
        return fanId;
    }

    public void setFanId(int fanId) {
        this.fanId = fanId;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public AlbumTracker getAlbumTracker() {
        return albumTracker;
    }

    public void setAlbumTracker(AlbumTracker albumTracker) {
        this.albumTracker = albumTracker;
    }

    public PesmaTracker getPesmaTracker() {
        return pesmaTracker;
    }

    public void setPesmaTracker(PesmaTracker pesmaTracker) {
        this.pesmaTracker = pesmaTracker;
    }

    public List<Plejlista> getPlejliste() {
        return plejliste;
    }

    public void setPlejliste(List<Plejlista> plejliste) {
        this.plejliste = plejliste;
    }

    public List<Izvodjac> getOmiljeniIzvodjaci() {
        return omiljeniIzvodjaci;
    }

    public void setOmiljeniIzvodjaci(List<Izvodjac> omiljeniIzvodjaci) {
        this.omiljeniIzvodjaci = omiljeniIzvodjaci;
    }

    public List<Obavestenje> getObavestenja() {
        return obavestenja;
    }

    public void setObavestenja(List<Obavestenje> obavestenja) {
        this.obavestenja = obavestenja;
    }

    public List<Izvodjac> getPraceniIzvodjaci() {
        return praceniIzvodjaci;
    }

    public void setPraceniIzvodjaci(List<Izvodjac> praceniIzvodjaci) {
        this.praceniIzvodjaci = praceniIzvodjaci;
    }

    public void dodajOmiljenogIzvodjaca(Izvodjac izvodjac) {
        omiljeniIzvodjaci.add(izvodjac);
        System.out.println("Dodali ste izvođača " + izvodjac.getIme() + " među omiljene izvođače.");
    }

    public void poveziSaIzvodjacem(Izvodjac izvodjac) {
        praceniIzvodjaci.add(izvodjac);
        System.out.println("Pratite izvođača: " + izvodjac.getIme());
    }

    public void dodajPlejlistu(Plejlista plejlista) {
        plejliste.add(plejlista);
        System.out.println("Dodali ste plejlistu: " + plejlista.getNaziv());
    }

    public void dodajObavestenje(Obavestenje obavestenje) {
        obavestenja.add(obavestenje);
        System.out.println("Primili ste obaveštenje: " + obavestenje.getNaslov());
    }

    public void prikaziInformacije() {
        System.out.println("Prikaz informacija o albumima i pesmama:");
        if (albumTracker != null) {
            // Prikaz informacija o albumima
            List<Album> albumi = albumTracker.getAlbumi();
            for (Album album : albumi) {
                System.out.println("Album: " + album.getNaziv() + ", Izvođač: " + album.getIzvodjac().getIme());
            }
        } else {
            System.out.println("Nema dostupnih informacija o albumima.");
        }

        if (pesmaTracker != null) {
            // Prikaz informacija o pesmama
            List<Pesma> pesme = pesmaTracker.getPesme();
            for (Pesma pesma : pesme) {
                System.out.println("Pesma: " + pesma.getNaziv() + ", Trajanje: " + pesma.getTrajanje());
            }
        } else {
            System.out.println("Nema dostupnih informacija o pesmama.");
        }
    }

    public void prikaziNovosti() {
        System.out.println("Prikaz novosti:");
        if (obavestenja != null && !obavestenja.isEmpty()) {
            for (Obavestenje obavestenje : obavestenja) {
                System.out.println("Naslov: " + obavestenje.getNaslov() + ", Posiljalac: " + obavestenje.getPosiljalac());
            }
        } else {
            System.out.println("Nema dostupnih novosti.");
        }
    }

    public String getPrezime() {
        return prezime != null ? prezime : "";
    }

    public String getEmail() {
        return email != null ? email : "";
    }

}

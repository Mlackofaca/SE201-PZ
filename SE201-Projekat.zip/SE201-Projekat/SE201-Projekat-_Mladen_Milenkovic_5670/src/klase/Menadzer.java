/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Menadzer {

    private int menadzerId;
    private String ime;
    private String prezime;
    private String korisnickoIme;
    private String lozinka;
    private List<Koncert> koncerti;
    private List<Obavestenje> obavestenja;

    public Menadzer(String ime, String prezime, String korisnickoIme, String lozinka) {
        this.ime = ime;
        this.prezime = prezime;
        this.korisnickoIme = korisnickoIme;
        this.lozinka = lozinka;
        this.koncerti = new ArrayList<>();
        this.obavestenja = new ArrayList<>();
    }

    public int getMenadzerId() {
        return menadzerId;
    }

    public void dodajObavestenje(Obavestenje obavestenje) {
        this.obavestenja.add(obavestenje);
    }

    public void setMenadzerId(int menadzerId) {
        this.menadzerId = menadzerId;
    }

    public String getIme() {
        return ime;
    }

    public List<Obavestenje> getObavestenja() {
        return obavestenja;
    }

    public void setObavestenja(List<Obavestenje> obavestenja) {
        this.obavestenja = obavestenja;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public void setKorisnickoIme(String korisnickoIme) {
        this.korisnickoIme = korisnickoIme;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public List<Koncert> getKoncerti() {
        return koncerti;
    }

    public void setKoncerti(List<Koncert> koncerti) {
        this.koncerti = koncerti;
    }

    @Override
    public String toString() {
        return "Menadzer{" + "menadzerId=" + menadzerId + ", ime=" + ime + ", prezime=" + prezime + ", korisnickoIme=" + korisnickoIme + ", lozinka=" + lozinka + ", koncerti=" + koncerti + ", obavestenja=" + obavestenja + '}';
    }

    public void addKoncert(Connection connection, Koncert koncert) {
        String query = "INSERT INTO koncerti (datum, lokacija, zarada, menadzer_id) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setDate(1, new java.sql.Date(koncert.getDatum().getTime()));
            preparedStatement.setString(2, koncert.getLokacija());
            preparedStatement.setDouble(3, koncert.getZarada());
            preparedStatement.setInt(4, menadzerId);

            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Dodavanje koncerta nije uspelo, nijedan red nije izmenjen.");
            }

            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    koncert.setKoncertId(generatedKeys.getInt(1));
                    koncerti.add(koncert);
                } else {
                    throw new SQLException("Dodavanje koncerta nije uspelo, nije dobio ID.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadKoncerti(Connection connection) {
        String query = "SELECT * FROM koncerti WHERE menadzer_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, menadzerId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    int koncertId = resultSet.getInt("koncert_id");
                    Date datum = resultSet.getDate("datum");
                    String lokacija = resultSet.getString("lokacija");
                    double zarada = resultSet.getDouble("zarada");

                    Koncert koncert = new Koncert(datum, lokacija, zarada);
                    koncert.setKoncertId(koncertId);
                    koncerti.add(koncert);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

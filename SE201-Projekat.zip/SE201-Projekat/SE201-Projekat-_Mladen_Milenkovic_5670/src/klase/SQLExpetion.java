/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package klase;


public class SQLExpetion extends Exception {

    public SQLExpetion(String message) {
        super(message);
    }

}

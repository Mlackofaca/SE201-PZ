/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BruteForce;


import java.security.NoSuchAlgorithmException;

import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class BruteForce {

    public static void bruteForcePasswords(Connection connection) {
        try {
            String query = "SELECT korisnicko_ime, lozinka, salt FROM menadzeri";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    String korisnickoIme = resultSet.getString("korisnicko_ime");
                    String storedPasswordHash = resultSet.getString("lozinka");
                    String salt = resultSet.getString("salt");

                    // Simulacija provere lozinke
                    boolean isValid = checkPassword(connection, korisnickoIme, storedPasswordHash, salt);
                    if (isValid) {
                        System.out.println("Pronađena ispravna lozinka za korisničko ime: " + korisnickoIme);
                        // Dodajte dodatne radnje ako je lozinka pronađena
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static boolean checkPassword(Connection connection, String korisnickoIme, String storedPasswordHash, String salt) {
        // Implementacija stvarne provere lozinke sa "salt" vrednošću i PBKDF2 heširanjem
        String userInputPassword = "test"; // Ovde treba uneti stvarno unetu lozinku
        String hashedInputPassword = hashPassword(userInputPassword, salt);

        return storedPasswordHash.equals(hashedInputPassword);
    }

    private static String hashPassword(String password, String salt) {
        // Implementacija PBKDF2 heširanja
        int iterations = 10000;
        char[] chars = password.toCharArray();
        byte[] saltBytes = hexStringToByteArray(salt);

        PBEKeySpec spec = new PBEKeySpec(chars, saltBytes, iterations, 64 * 8);

        try {
            SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            byte[] hash = skf.generateSecret(spec).getEncoded();
            return byteArrayToHexString(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            e.printStackTrace();
        }

        return null;
    }

    private static byte[] hexStringToByteArray(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];

        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }

        return data;
    }

    private static String byteArrayToHexString(byte[] array) {
        StringBuilder result = new StringBuilder();

        for (byte b : array) {
            result.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
        }

        return result.toString();
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projekat;

import BruteForce.BruteForce;
import java.sql.*;
import java.util.Date;
import klase.*;

public class Projekat {

    public static void main(String[] args) {

        Connection connection = null;
        try {
            // Povezivanje na bazu podataka
            connection = DatabaseConnector.getConnection();

           // Kreiranje fanova
            Fan fan1 = new Fan("Ime1", "Prezime1", "email1@example.com");
            Fan fan2 = new Fan("Ime2", "Prezime2", "email2@example.com");

            // Dodavanje fanova u bazu podataka
            fan1.setFanId(addFan(connection, fan1));
            fan2.setFanId(addFan(connection, fan2));

            // Prikaz informacija o fanovima
            System.out.println("Fan 1: " + fan1.getIme() + ", " + fan1.getPrezime() + ", " + fan1.getEmail());
            System.out.println("Fan 2: " + fan2.getIme() + ", " + fan2.getPrezime() + ", " + fan2.getEmail());

            // Kreiranje objekta Menadzer
            Menadzer menadzer = new Menadzer("ImeMenadzera", "PrezimeMenadzera", "korisnik", "lozinka");

            // Dodavanje menadžera u bazu podataka
            menadzer.setMenadzerId(addMenadzer(connection, menadzer));

            // Kreiranje objekta Izvodjac
            Izvodjac izvodjac = new Izvodjac("Izvodjac Ime");

            // Dodavanje izvođača u bazu podataka
            izvodjac.setIzvodjacId(addIzvodjac(connection, izvodjac));

            // Kreiranje objekta Album
            Album album = new Album("Naziv Albuma");

            // Dodavanje albuma izvođaču
            izvodjac.dodajAlbum(album);
            izvodjac.addAlbum(connection, album);

            // Kreiranje objekta Koncert
            Koncert koncert = new Koncert(new Date(), "Lokacija koncerta", 1500.0);

            // Kreiranje objekta Ugovor
            Ugovor ugovor = new Ugovor("Tip ugovora", 1000.0);

            // Povezivanje ugovora sa izvođačem
            ugovor.setIzvodjac(izvodjac);

            // Dodavanje ugovora izvođaču
            izvodjac.dodajUgovor(ugovor);

            // Dodavanje koncerta u plejlistu
            Plejlista plejlista = new Plejlista("Moja Plejlista");
            plejlista.dodajKoncert(koncert);

            // Povezivanje ugovora sa koncertom
            ugovor.setKoncert(koncert);

            // Dodavanje pesme u album izvođača
            Pesma pesma = new Pesma("Pesma 1", "3:30");
            album.dodajPesmu(pesma);
            album.addPesma(connection, pesma);

            // Dodavanje novčanog prihoda tokom koncerta
            NovcaniPrihod novcaniPrihod = new NovcaniPrihod(new Date(), 500.0);
            koncert.dodajNovcaniPrihod(novcaniPrihod);

            // Slanje obaveštenja menadžeru o uspešnom koncertu
            String obavestenjeTekst = "Uspešan koncert na lokaciji: " + koncert.getLokacija();
            Obavestenje obavestenje = new Obavestenje("Uspešan koncert", obavestenjeTekst, new Date(), "Sistem");
            menadzer.dodajObavestenje(obavestenje);

            // Prikaz koncerata u plejlisti
            System.out.println("Koncerti u plejlisti:");
            for (Koncert k : plejlista.getKoncerti()) {
                System.out.println("ID: " + k.getKoncertId() + ", Datum: " + k.getDatum() + ", Zarada: " + k.getZarada());
                System.out.println("Novčani prihodi za koncert:");
                for (NovcaniPrihod np : k.getNovcaniPrihodi()) {
                    System.out.println("Datum: " + np.getDatum() + ", Iznos: " + np.getIznos());
                }

                // Prikaz finansijskih transakcija za koncert
                k.prikaziFinansijskeTransakcije();
            }

            // Poziv brute force funkcije
            BruteForce.bruteForcePasswords(connection);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Dodavanje fanova u bazu
    private static int addFan(Connection connection, Fan fan) {
        String query = "INSERT INTO fanovi (ime, prezime, email) VALUES (?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, fan.getIme());
            preparedStatement.setString(2, fan.getPrezime());
            preparedStatement.setString(3, fan.getEmail());

            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Dodavanje fana nije uspelo, nijedan red nije izmenjen.");
            }

            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Dodavanje fana nije uspelo, nije dobio ID.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }

    private static int addMenadzer(Connection connection, Menadzer menadzer) {
        String query = "INSERT INTO menadzeri (ime, prezime, korisnicko_ime, lozinka) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, menadzer.getIme());
            preparedStatement.setString(2, menadzer.getPrezime());
            preparedStatement.setString(3, menadzer.getKorisnickoIme());
            preparedStatement.setString(4, menadzer.getLozinka());

            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Dodavanje menadžera nije uspelo, nijedan red nije izmenjen.");
            }

            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Dodavanje menadžera nije uspelo, nije dobio ID.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }

    private static int addIzvodjac(Connection connection, Izvodjac izvodjac) {
        String query = "INSERT INTO izvodjaci (ime) VALUES (?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, izvodjac.getIme());

            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Dodavanje izvođača nije uspelo, nijedan red nije izmenjen.");
            }

            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Dodavanje izvođača nije uspelo, nije dobio ID.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Test;

import static org.junit.jupiter.api.Assertions.*;
import klase.Fan;
import org.junit.jupiter.api.Test;

public class FanTest {

    @Test
    public void testValidEmail() {
        assertTrue(Fan.isValidEmail("test@example.com"));
        assertFalse(Fan.isValidEmail("invalid_email"));
    }

    @Test
    public void testValidLastName() {
        assertTrue(Fan.isValidLastName("Doe"));
        assertFalse(Fan.isValidLastName(""));
        assertFalse(Fan.isValidLastName(null));
        assertFalse(Fan.isValidLastName("ThisLastNameIsLongerThanFiftyCharactersAndShouldFailValidation"));
    }

    @Test
    public void testValidString() {
        assertTrue(Fan.isValidString("ValidString"));
        assertFalse(Fan.isValidString(""));
        assertFalse(Fan.isValidString(null));
    }

    @Test
    public void testFanCreationValid() {
        Fan fan = new Fan("John", "Doe", "john.doe@example.com");
        assertNotNull(fan);
        assertEquals("John", fan.getIme());
        assertEquals("Doe", fan.getPrezime());
        assertEquals("john.doe@example.com", fan.getEmail());
    }

    @Test
    public void testFanCreationInvalid() {
        // Testiranje nevalidnih ulaznih vrednosti pri kreiranju fana
        assertThrows(IllegalArgumentException.class, () -> new Fan(null, "Doe", "john.doe@example.com"));
        assertThrows(IllegalArgumentException.class, () -> new Fan("John", "", "john.doe@example.com"));
        assertThrows(IllegalArgumentException.class, () -> new Fan("John", "Doe", "invalid_email"));
    }
}
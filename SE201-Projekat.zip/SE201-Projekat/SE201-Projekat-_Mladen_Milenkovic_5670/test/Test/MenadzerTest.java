/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import klase.Koncert;
import klase.Menadzer;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
class MenadzerTest {

    @Test
    void testAddKoncert() throws SQLException {
        // Konektujem se na  bazu podataka 
        String url = "jdbc:mysql://localhost:3306/projekat";
        String username = "root";
        String password = "";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // Očekujem da ova konekcija bude otvorena i ispravna

            // Kreiram instancu Menadzer klase
            Menadzer menadzer = new Menadzer("Ime", "Prezime", "korisnik", "lozinka");
            menadzer.setMenadzerId(1); // Postavljam ID menadžera

            // Kreiram instancu Koncert klase
            Koncert koncert = new Koncert(new Date(), "Lokacija", 100.0);

            // Pozivam metodu koju želimo testirati
            menadzer.addKoncert(connection, koncert);

            // Proveravam da li je koncert dodat u listu koncerata menadžera
            assertEquals(1, menadzer.getKoncerti().size());
            // Proveravam da li je koncert dobio ispravan ID
            assertNotNull(koncert.getKoncertId());
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Test;

import klase.Album;
import klase.Pesma;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

class PesmaTest {

    @Test
    void testDodajTrend() {
        Pesma pesma = new Pesma("Pesma1", "03:30", 1, new Album("Album1"));
        pesma.dodajTrend("Trend1");
        pesma.dodajTrend("Trend2");

        List<String> trendovi = pesma.getTrendovi();
        assertEquals(2, trendovi.size());
        assertTrue(trendovi.contains("Trend1"));
        assertTrue(trendovi.contains("Trend2"));
    }

    @Test
    void testDodajUBazu() {
        Pesma pesma = new Pesma("Pesma2", "04:15", 2, new Album("Album2"));

        String dbUrl = "jdbc:mysql://localhost:3306/tvoja_baza";
        String dbUsername = "tvoj_username";
        String dbPassword = "tvoja_lozinka";

        try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
         
            createTempTable(connection);

            pesma.dodajUBazu(connection);

            // Provera da li se pesma nalazi u bazi
            assertTrue(checkIfSongExists(connection, pesma.getNaziv()));
        } catch (SQLException e) {
            e.printStackTrace();
            fail("Exception thrown during test: " + e.getMessage());
        }
    }

    private void createTempTable(Connection connection) throws SQLException {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS pesme (" +
                "id INT PRIMARY KEY AUTO_INCREMENT," +
                "naziv VARCHAR(255) NOT NULL," +
                "trajanje TIME NOT NULL," +
                "izvodjac_id INT NOT NULL," +
                "album_naziv VARCHAR(255)," +
                "CONSTRAINT fk_album FOREIGN KEY (album_naziv) REFERENCES albumi(naziv)" +
                ");";

        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(createTableQuery);
        }
    }

    private boolean checkIfSongExists(Connection connection, String naziv) throws SQLException {
        String checkQuery = "SELECT COUNT(*) FROM pesme WHERE naziv = ?";
        try (java.sql.PreparedStatement preparedStatement = connection.prepareStatement(checkQuery)) {
            preparedStatement.setString(1, naziv);
            try (java.sql.ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count == 1;
                }
            }
        }
        return false;
    }
}
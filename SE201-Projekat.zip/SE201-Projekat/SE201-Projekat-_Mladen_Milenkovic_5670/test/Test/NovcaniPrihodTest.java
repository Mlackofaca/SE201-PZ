/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Test;
import org.junit.jupiter.api.Test;

import java.util.Date;
import klase.NovcaniPrihod;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class NovcaniPrihodTest {

    @Test
    void testKonstruktorISettere() {
        Date datum = new Date();
        double iznos = 1000.0;

        NovcaniPrihod novcaniPrihod = new NovcaniPrihod(datum, iznos);

        assertNotNull(novcaniPrihod.getDatum());
        assertEquals(datum, novcaniPrihod.getDatum());

        assertEquals(iznos, novcaniPrihod.getIznos());
    }

    @Test
    void testToString() {
        Date datum = new Date();
        double iznos = 1500.0;

        NovcaniPrihod novcaniPrihod = new NovcaniPrihod(datum, iznos);

        String ocekivano = "NovcaniPrihod{datum=" + datum + ", iznos=" + iznos + '}';
        assertEquals(ocekivano, novcaniPrihod.toString());
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Test;

import org.junit.jupiter.api.Test;

import java.util.Date;
import klase.Obavestenje;

import static org.junit.jupiter.api.Assertions.*;

class ObavestenjeTest {

    @Test
    void testDodajKomentar() {
        Obavestenje obavestenje = new Obavestenje("Naslov", "Sadrzaj", new Date(), "Izvor");
        obavestenje.dodajKomentar("Prvi komentar");

        assertEquals(1, obavestenje.getKomentari().size());
        assertEquals("Prvi komentar", obavestenje.getKomentari().get(0));
    }

    @Test
    void testPrikaziInformacije() {
        Obavestenje obavestenje = new Obavestenje("Naslov", "Sadrzaj", new Date(), "Izvor");
        obavestenje.dodajKomentar("Prvi komentar");
        obavestenje.dodajKomentar("Drugi komentar");

        String ocekivano = "Naslov: Naslov\n" +
                "Sadrzaj: Sadrzaj\n" +
                "Datum objave: " + obavestenje.getDatumObjave() + "\n" +
                "Izvor: Izvor\n" +
                "Komentari:\n" +
                "- Prvi komentar\n" +
                "- Drugi komentar\n";

        String rezultat = captureSystemOut(() -> obavestenje.prikaziInformacije());

        assertEquals(ocekivano, rezultat);
    }

    private String captureSystemOut(Runnable runnable) {
        var oldOut = System.out;
        try {
            var newOut = new java.io.ByteArrayOutputStream();
            System.setOut(new java.io.PrintStream(newOut));

            runnable.run();

            return newOut.toString();
        } finally {
            System.setOut(oldOut);
        }
    }
}